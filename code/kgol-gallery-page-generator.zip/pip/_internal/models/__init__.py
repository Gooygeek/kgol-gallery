from pip._internal.models.index import Index, PyPI


__all__ = ["Index", "PyPI"]
